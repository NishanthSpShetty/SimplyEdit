#ifndef CSYNTAX_H
#define CSYNTAX_H

#define DATA_TYPE 0x01
#define LOOP 0x02
#define NUMBER 0x03
#define LANG_CONSTRUCT 0x04
#define RETURN 0x05
#endif
